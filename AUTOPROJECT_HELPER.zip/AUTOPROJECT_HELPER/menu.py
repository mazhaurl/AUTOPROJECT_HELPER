import nuke

import AUTO_PROJECT_HELPER


nuke.menu('Nuke').addMenu('AUTO PROJECT HELPER').addCommand('AUTO_PROJECT_HELPER','AUTO_PROJECT_HELPER.AUTO_PROJECT_HELPER()','shift+P', shortcutContext=2)