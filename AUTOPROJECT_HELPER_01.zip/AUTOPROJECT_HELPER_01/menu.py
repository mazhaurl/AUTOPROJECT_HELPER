import nuke

import AUTO_PROJECT_HELPER_01


nuke.menu('Nuke').addMenu('AUTO PROJECT HELPER').addCommand('AUTO_PROJECT_HELPER','AUTO_PROJECT_HELPER_01.AUTO_PROJECT_HELPER()','shift+P', shortcutContext=2)